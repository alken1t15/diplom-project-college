package kz.alken1t15.backratinglogcollege.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserId {
    private Long id;
    private Integer numberOfMonth;
}