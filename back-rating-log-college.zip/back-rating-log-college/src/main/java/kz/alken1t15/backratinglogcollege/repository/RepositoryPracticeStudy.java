package kz.alken1t15.backratinglogcollege.repository;

import kz.alken1t15.backratinglogcollege.entity.PracticeStudy;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryPracticeStudy extends JpaRepository<PracticeStudy,Long> {
}
