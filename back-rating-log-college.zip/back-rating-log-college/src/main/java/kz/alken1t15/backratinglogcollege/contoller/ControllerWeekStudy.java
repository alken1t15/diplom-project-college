package kz.alken1t15.backratinglogcollege.contoller;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("/week/study")
public class ControllerWeekStudy {
}
