package kz.alken1t15.backratinglogcollege.dto;

public enum Semester {
    FIRST,SECOND
}