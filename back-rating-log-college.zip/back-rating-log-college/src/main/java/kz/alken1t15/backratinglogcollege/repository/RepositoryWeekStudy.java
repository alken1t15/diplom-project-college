package kz.alken1t15.backratinglogcollege.repository;

import kz.alken1t15.backratinglogcollege.entity.WeekStudy;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryWeekStudy extends JpaRepository<WeekStudy,Long> {

}